// update-member.dto.ts
import { CreateMemberDto } from './create-member.dto';

export class UpdateMemberDto extends CreateMemberDto {}
